#include <bits/stdc++.h>

using namespace std;

class matrix
{
    int row, col;
    int ara[101][101];
public:

};

int main()
{

    return 0;
}
