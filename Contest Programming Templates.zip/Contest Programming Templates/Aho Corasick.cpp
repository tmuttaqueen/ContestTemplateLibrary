#include <bits/stdc++.h>
using namespace std ;

const int MAX = 1e6 + 5;
int totNodes;
int wordNode[MAX];

struct Node
{
    int to[26] ;
    int depth ;
    int suffLink ;
    int par ;
    int parLet ;
    bool word ;
};
Node states[MAX];

int add (string &str)
{
    int cur = 1 ; // root with a empty string
    for ( int i = 0; i < str.length(); i++)
    {
        char c = str[i];
        int let = c - 'a';
        if (!states[cur].to[let])
        {
            states[cur].to[let] = ++totNodes ;
            states[totNodes].par = cur ;
            states[totNodes].depth = states[cur].depth + 1 ;
            states[totNodes].parLet = let ;
        }
        cur = states[cur].to[let];
    }
    states[cur].word = true ;
    return cur ;
}

void pushLinks()
{
    queue <int> Q ;
    Q.push(1) ;
    while (!Q.empty())
    {
        int node = Q.front() ;
        Q.pop() ;
        if (states[node].depth <= 1)
        {
            states[node].suffLink = 1 ;
        }
        else
        {
            int cur = states[states[node].par].suffLink ;
            int parLet = states[node].parLet ;
            while (cur > 1 and !states[cur].to[parLet])
            {
                cur = states[cur].suffLink ;
            }
            if (states[cur].to[parLet])
            {
                cur = states[cur].to[parLet] ;
            }
            states[node].suffLink = cur ;
        }
        //in case you need from which nodes suffLink comes
        //if (node != 1) g[states[node].suffLink].push_back(node) ;
        for (int i = 0 ; i < 26 ; i++)
        {
            if (states[node].to[i])
            {
                Q.push(states[node].to[i]) ;
            }
        }
    }
}

void init(int n = MAX-1)
{
    totNodes = 1;
    for( int i = 0; i <= n; i++ )
    {
        for( int j = 0; j < 26; j++ )
            states[i].to[j] = 0;
        states[i].depth = 0;
        states[i].par = -1;
        states[i].parLet = -1;
        states[i].suffLink = -1;
        states[i].word = 0;
    }
}

int main ()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    string str ;
    cin >> n ;
    init();
    for (int i = 1 ; i <= n ; i++)
    {
        cin >> str ;
        wordNode[i] = add(str) ;
    }
    pushLinks() ;
    return 0;
}

