#include<bits/stdc++.h>

using namespace std;

class NT
{
public:

    ///returns gcd of a and b
    long long gcd( long long a, long long b )
    {
        if( b == 0 ) return a;
        else return gcd( b, a%b );
    }
    /// returns lcm of a and b
    long long lcm( long long a, long long b )
    {
        long long g = gcd(a,b);
        a = a/g;
        return a*b;
    }
    /// return 1 if n is prime, 0 otherwise
    int isPrime( long long n )
    {
        if( n == 2 ) return 1;
        if( n % 2 == 0 ) return 0;

        long long d = n-1;
        while(d%2==0) d/=2;

        int test[] = {2,3,5,7,11,13,17,19,23,29};
        for( int i = 0; i < 10; i++ )
        {
            unsigned long long x = test[i]%(n-2), temp = d;
            if(x < 2) x += 2;
            //use mulmod() in exponentiation for n>1e9
            long long a = exponentiation(x,d,n, 1);
            while( temp != n-1 && a != 1 && a != n-1 )
            {
                a = mulmod(a,a,n);
                temp *= 2;
            }
            if( a != n-1 && temp%2==0 )
                return 0;
        }
        return 1;
    }
    /// returns (a*b)%mod when a*b > 1e18
    long long mulmod( long long a, long long b, long long mod )
    {
        long long x = 0, y = a%mod;
        while( b > 0 )
        {
            if(b&1)
                x = (x+y)%mod;
            y = (y*2)%mod;
            b /= 2;
        }
        return x%mod;
    }
    ///returns (a^b)%mod
    long long exponentiation( long long a, long long b, long long mod, bool mulmd = 0 )
    {
        long long ans = 1;
        while( b > 0 )
        {
            if( b&1 )
            {
                if( !mulmd )
                    ans = (a*ans)%mod;
                else
                    ans = mulmod( a, ans, mod );
            }
            if( !mulmd )
                a = (a*a)%mod;
            else
                a = mulmod( a, a, mod );
            b /= 2;
        }
        return ans;
    }
    ///returns (1/a)%mod
    long long modInverse( long long a, long long mod, bool isPrime = 1 )
    {
        if( isPrime )
        {
            return exponentiation( a, mod-2, mod );
        }
        else
        {
            pair<long long, long long> pp = extendedEuclid( a, mod );
            return pp.xx;
        }
    }
    ///given a ,b returns x, y such that ax+by = gcd(a,b)
    pair<long long, long long> extendedEuclid( long long a, long long b )
    {
        long long x, y;
        exEuclid(a,b,x,y);
        return make_pair(x,y);
    }

    void exEuclid( long long a, long long b, long long &x, long long &y)
    {
        if(b == 0)
        {
            x = 1;
            y = 0;
            return;
        }
        extendedEuclid( b, a%b, x, y );
        long long temp = x;
        x = y;
        y = temp - (a/b)*y;
        return;
    }

};
