#include<cstdio>
#include<iostream>
using namespace std;

template<typename T>
class Bit1D
{
    int sz;
    T *bit;
public:
    Bit1D( int n = 200000 )
    {
        n += 5;
        sz = n;
        bit = new T[sz];
        init();
    }
    void init(T v = 0)
    {
        for( int i = 0; i < sz; i++ )
            bit[i] = v;
    }
    void add( int x, T val ) //add val to index x
    {
        while( x < sz )
        {
            bit[x] += val;
            x += (x&(-x));
        }
    }

    T query( int x ) //sum from 1 to x (inclusive)
    {
        T sum = 0;
        while( x > 0 )
        {
            sum += bit[x];
            x -= (x&(-x));
        }
        return sum;
    }
};

int main()
{
    Bit1D<long long> bit(1000);
    bit.add( 2, 4000000000000LL );
    bit.add( 3, 6 );
    cout << bit.query(10) << endl;
    cout << bit.query(2) << endl;
}
